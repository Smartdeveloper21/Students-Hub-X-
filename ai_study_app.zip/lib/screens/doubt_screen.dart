import 'package:flutter/material.dart';

class DoubtScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Doubt Section'));
  }
}
